# DRIP 核心写作参考（4 篇）

## 建议阅读顺序

1. **Non-Stationary KG-RAG (AAAI 2025)**
   - 用于 Introduction 和 Problem Formulation。
   - 借鉴：非平稳 RAG、在线反馈、质量与成本的多目标权衡。
   - 区别：它选择检索器，DRIP 选择受容量和 replacement 约束的 evidence set。

2. **Mnemosyne (AAAI 2026)**
   - 用于 RAG cache 的动机、系统叙事和实验组织。
   - 借鉴：有限缓存、cache miss、latency 与 answer quality 联合评价。
   - 区别：它重排多跳子查询并使用多粒度缓存，不处理跨窗口常驻 evidence replacement。

3. **DDG-DA (AAAI 2022)**
   - 用于 Transition-Conditioned Evidence Forecasting。
   - 借鉴：从被动检测已经发生的漂移，推进到预测未来数据分布并提前适应。
   - 区别：它预测一般数据分布；DRIP 预测下一窗口 evidence working set。

4. **LogicRAG (AAAI 2026)**
   - 用于 Design 章节和 hidden evidence 的写作结构。
   - 借鉴：三阶段方法叙述、统一主公式、框架图、完整 ablation，以及 direct retrieval 无法表达关系依赖的动机。
   - 区别：它动态构造推理 DAG；DRIP 将完整 hidden evidence 表示为受缓存容量约束的 hyperedge。

## 对应 DRIP 章节

| DRIP 章节 | 首要参考 |
|---|---|
| Introduction / Motivation | Non-Stationary KG-RAG, Mnemosyne |
| Problem Formulation | Non-Stationary KG-RAG |
| Predictive Evidence Forecast | DDG-DA |
| Unified Method / Hidden Evidence | LogicRAG |
| Experiments | Mnemosyne, LogicRAG |

这四篇主要负责 AAAI 写作叙事。正式 Method/Related Work 仍需引用 LeCaR、MMD/KCUSUM、MITHRIL 和 online primal-dual long-term constraints 等经典技术来源。
